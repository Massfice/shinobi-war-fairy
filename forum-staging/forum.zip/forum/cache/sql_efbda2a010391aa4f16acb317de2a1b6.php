<?php exit; ?>
1609977196
SELECT forum_id FROM phpbb11_forums WHERE forum_options & 2 <> 0 LIMIT 1
6
a:0:{}