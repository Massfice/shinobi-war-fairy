<?php
// phpBB 3.0.x auto-generated configuration file
// Do not change anything in this file!
$dbms = 'mysqli';
$dbhost = 'forum-db';
$dbport = '3306';
$dbname = 'bitnami_phpbb';
$dbuser = 'bn_phpbb';
$dbpasswd = '';
$table_prefix = getenv('SHINOBI_WAR_FAIRY_DB_PREFIX') . '_';
$acm_type = 'file';
$load_extensions = '';

@define('PHPBB_INSTALLED', true);
// @define('DEBUG', true);
// @define('DEBUG_EXTRA', true);
