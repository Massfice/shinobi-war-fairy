rm -R ./.output && mkdir ./.output && php modx_gen.php ./unchanged ./changed -r ./.output -m ./.output/install.xml
