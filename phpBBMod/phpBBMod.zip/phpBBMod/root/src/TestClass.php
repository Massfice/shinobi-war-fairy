<?php

class TestClass {
    public function testMethod() {
        echo 'test, test, test';
    }
}

?>